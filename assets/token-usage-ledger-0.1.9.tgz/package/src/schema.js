export const usageEventsColumns = [
  "id",
  "created_at",
  "started_at",
  "ended_at",
  "duration_ms",
  "time_to_first_token_ms",
  "gateway_profile",
  "agent_id",
  "agent_name",
  "runtime_id",
  "machine_identity",
  "platform",
  "channel_name",
  "platform_user_id",
  "platform_user_display_name",
  "platform_tenant_id",
  "platform_conversation_id",
  "platform_message_id",
  "thread_id",
  "session_key",
  "session_id",
  "run_id",
  "turn_id",
  "request_id",
  "provider_request_id",
  "call_source",
  "provider",
  "model",
  "input_tokens",
  "output_tokens",
  "total_tokens",
  "cache_read_tokens",
  "cache_write_tokens",
  "reasoning_tokens",
  "estimated_cost_usd",
  "input_cost_usd",
  "output_cost_usd",
  "cache_cost_usd",
  "cost_mode",
  "context_tokens_before",
  "context_tokens_after",
  "context_window",
  "had_tool_calls",
  "tool_call_count",
  "tool_names_json",
  "status",
  "error_code",
  "error_message",
  "retry_count",
  "prompt_hash",
  "response_hash",
  "preview",
  "raw_usage_json",
  "metadata_json"
];

export const createSchemaSql = `
CREATE TABLE IF NOT EXISTS usage_events (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  started_at TEXT,
  ended_at TEXT,
  duration_ms INTEGER,
  time_to_first_token_ms INTEGER,
  gateway_profile TEXT,
  agent_id TEXT,
  agent_name TEXT,
  runtime_id TEXT,
  machine_identity TEXT,
  platform TEXT,
  channel_name TEXT,
  platform_user_id TEXT,
  platform_user_display_name TEXT,
  platform_tenant_id TEXT,
  platform_conversation_id TEXT,
  platform_message_id TEXT,
  thread_id TEXT,
  session_key TEXT,
  session_id TEXT,
  run_id TEXT,
  turn_id TEXT,
  request_id TEXT,
  provider_request_id TEXT,
  call_source TEXT,
  provider TEXT,
  model TEXT,
  input_tokens INTEGER DEFAULT 0,
  output_tokens INTEGER DEFAULT 0,
  total_tokens INTEGER DEFAULT 0,
  cache_read_tokens INTEGER DEFAULT 0,
  cache_write_tokens INTEGER DEFAULT 0,
  reasoning_tokens INTEGER DEFAULT 0,
  estimated_cost_usd REAL DEFAULT 0,
  input_cost_usd REAL DEFAULT 0,
  output_cost_usd REAL DEFAULT 0,
  cache_cost_usd REAL DEFAULT 0,
  cost_mode TEXT,
  context_tokens_before INTEGER,
  context_tokens_after INTEGER,
  context_window INTEGER,
  had_tool_calls INTEGER DEFAULT 0,
  tool_call_count INTEGER DEFAULT 0,
  tool_names_json TEXT,
  status TEXT,
  error_code TEXT,
  error_message TEXT,
  retry_count INTEGER DEFAULT 0,
  prompt_hash TEXT,
  response_hash TEXT,
  preview TEXT,
  raw_usage_json TEXT,
  metadata_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_usage_created_at
  ON usage_events(created_at);
CREATE INDEX IF NOT EXISTS idx_usage_user_time
  ON usage_events(platform, platform_user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_usage_model_time
  ON usage_events(provider, model, created_at);
CREATE INDEX IF NOT EXISTS idx_usage_session_time
  ON usage_events(session_key, created_at);
CREATE INDEX IF NOT EXISTS idx_usage_source_time
  ON usage_events(call_source, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_usage_provider_request
  ON usage_events(provider_request_id)
  WHERE provider_request_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS mirror_outbox (
  id TEXT PRIMARY KEY,
  payload_json TEXT NOT NULL,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  last_attempt_at TEXT,
  next_retry_at TEXT,
  last_error TEXT,
  synced_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_mirror_outbox_due
  ON mirror_outbox(synced_at, next_retry_at, updated_at);
`;
